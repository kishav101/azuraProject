USE msdb;
GO

EXEC sp_add_job
    @job_name = N'InsertVehicles',
    @enabled = 1,
    @description = N'Inserts BMW and VW vehicles every 20 minutes';
GO

EXEC sp_add_jobstep
    @job_name = N'InsertVehicles',
    @step_name = N'Insert Vehicles Step',
    @subsystem = N'TSQL',
    @database_name = N'Azura',
    @command = N'EXEC dbo.InsertVehiclesJobProcedure';
GO

EXEC sp_add_schedule
    @schedule_name = N'Every 20 Min Schedule',
    @freq_type = 4,              
    @freq_interval = 1,         
    @freq_subday_type = 4,       
    @freq_subday_interval = 20,  
   
GO

EXEC sp_attach_schedule
    @job_name = N'InsertVehicles',
    @schedule_name = N'Every 20 Min Schedule';
GO

EXEC sp_add_jobserver
    @job_name = N'InsertVehicles',
GO
