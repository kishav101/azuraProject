USE Azura;
GO

IF OBJECT_ID('dbo.InsertVehiclesJobProcedure', 'P') IS NOT NULL
    DROP PROCEDURE dbo.InsertVehiclesJobProcedure;
GO

CREATE PROCEDURE dbo.InsertVehiclesJobProcedure
AS
BEGIN
    DECLARE @runCount INT = ISNULL((SELECT MAX(JobRunID) FROM dbo.JobTrackerTBL), 0) + 1;
    DECLARE @modelYear INT = 2000 + @runCount - 1;
    DECLARE @valueBMW INT = ROUND(RAND() * 50000 + 100000, 0);
    DECLARE @valueVW INT = ROUND(RAND() * 50000 + 100000, 0);
    DECLARE @kmBMW INT = ROUND(RAND() * 50000 + 50000, 0);
    DECLARE @kmVW INT = ROUND(RAND() * 50000 + 50000, 0);

    INSERT INTO VEHICLESTBL (MAKE, MODEL, KM, COLOR, LOCATION, VALUE)
    VALUES 
        ('Volkswagen', CAST(@modelYear AS VARCHAR), @kmVW, 'Black', 'JHB', @valueVW),
        ('BMW', CAST(@modelYear AS VARCHAR), @kmBMW, 'White', 'CT', @valueBMW);

    INSERT INTO dbo.JobTrackerTBL (JobRunID, RunDate)
    VALUES (@runCount, GETDATE());
END;
GO

EXEC dbo.InsertVehiclesJobProcedure;
