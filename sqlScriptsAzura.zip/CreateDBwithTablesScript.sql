
CREATE DATABASE Azura;
GO

USE Azura;
GO

CREATE TABLE VehiclesTbl (
    VehicleID INT IDENTITY(1,1) PRIMARY KEY,
    Make VARCHAR(100) NULL,
    Model VARCHAR(100) NULL,
    KM INT NULL,
    Color VARCHAR(50) NULL,
    Location VARCHAR(100) NULL,
    Value INT NULL
);
GO

CREATE TABLE JobTrackerTbl (
    JobRunID INT PRIMARY KEY,
    RunDate DATETIME DEFAULT GETDATE()
);
GO
